# ABS Token

Modular BEP20 token with PoT, airdrop, ICO, and dynamic reward/tax system.